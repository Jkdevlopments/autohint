# autohint/__init__.py

from .suggestion import search_bar